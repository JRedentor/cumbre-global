# cumbre-global
Sitio de la cumbre global de Gobierno Abierto
